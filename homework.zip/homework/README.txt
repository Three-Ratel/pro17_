﻿s17吴兴普
博客地址:
 http://blog.csdn.net/wuxingpu5
执行python manage.py runserver
首页访问url：http://127.0.0.1:8000/login.html









