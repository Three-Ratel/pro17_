from django.apps import AppConfig


class MyMamagerConfig(AppConfig):
    name = 'app01'
